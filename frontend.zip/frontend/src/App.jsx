
import React, { useEffect, useState } from 'react'
import axios from 'axios'
import {
  Box, Container, Typography, Paper, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, TablePagination, TextField, Drawer, Stack, Divider, Rating, Button
} from '@mui/material'

const PAGE_SIZES = [15, 25, 50]

function KV({label, value}){
  return (
    <Stack direction="row" spacing={1} sx={{py: 0.5}}>
      <Typography sx={{minWidth: 140, fontWeight: 600}}>{label}:</Typography>
      <Typography sx={{flex: 1}}>{value ?? '-'}</Typography>
    </Stack>
  )
}

export default function App(){
  const [rows, setRows] = useState([])
  const [page, setPage] = useState(0)
  const [rowsPerPage, setRowsPerPage] = useState(PAGE_SIZES[0])
  const [total, setTotal] = useState(0)
  const [loading, setLoading] = useState(false)
  const [drawer, setDrawer] = useState({open:false,row:null})
  const [filters, setFilters] = useState({ title:'', cuisine:'', rating:'', total_time:'', calories:'' })

  useEffect(()=>{ fetchData() }, [page, rowsPerPage, filters])

  const fetchData = async ()=>{
    setLoading(true)
    try{
      const hasFilter = Object.values(filters).some(v=>v && v.trim() !== '')
      const params = { page: page+1, limit: rowsPerPage, ...(hasFilter?filters:{}) }
      const url = hasFilter ? '/api/recipes/search' : '/api/recipes'
      const { data } = await axios.get(url, { params })
      setRows(data.data || [])
      setTotal(data.total || 0)
    }catch(e){
      console.error(e)
    }finally{ setLoading(false) }
  }

  const handleUpload = async (e) => {
    const file = e.target.files?.[0]; if(!file) return;
    const form = new FormData(); form.append('file', file);
    try{
      const res = await axios.post('/api/upload', form, { headers: { 'Content-Type':'multipart/form-data' } })
      alert(res.data)
      setPage(0)
      fetchData()
    }catch(err){ alert('Upload failed: '+ (err?.response?.data || err.message)) }
  }

  const cols = [
    { key:'title', label:'Title', width:'40%' },
    { key:'cuisine', label:'Cuisine', width:'15%' },
    { key:'rating', label:'Rating', width:'15%' },
    { key:'total_time', label:'Total Time', width:'15%' },
    { key:'serves', label:'Serves', width:'15%' }
  ]

  return (
    <Container maxWidth="lg" sx={{py:3}}>
      <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{mb:2}}>
        <Typography variant="h5" sx={{fontWeight:700}}>Recipes</Typography>
        <Button variant="contained" component="label">Upload JSON<input hidden type="file" accept=".json" onChange={handleUpload} /></Button>
      </Stack>

      <Stack direction="row" spacing={2} sx={{mb:2}}>
        <TextField size="small" label="Title (contains)" value={filters.title} onChange={e=>setFilters(f=>({...f,title:e.target.value}))}/>
        <TextField size="small" label="Cuisine" value={filters.cuisine} onChange={e=>setFilters(f=>({...f,cuisine:e.target.value}))}/>
        <TextField size="small" label="Rating (>=4.5)" value={filters.rating} onChange={e=>setFilters(f=>({...f,rating:e.target.value}))}/>
        <TextField size="small" label="Total Time (<=120)" value={filters.total_time} onChange={e=>setFilters(f=>({...f,total_time:e.target.value}))}/>
        <TextField size="small" label="Calories (<=400)" value={filters.calories} onChange={e=>setFilters(f=>({...f,calories:e.target.value}))}/>
      </Stack>

      <Paper>
        <TableContainer>
          <Table size="small">
            <TableHead>
              <TableRow>{cols.map(c=><TableCell key={c.key} sx={{width:c.width,fontWeight:700}}>{c.label}</TableCell>)}</TableRow>
            </TableHead>
            <TableBody>
              {!loading && rows.length===0 && <TableRow><TableCell colSpan={cols.length}><Typography align="center" sx={{py:4}}>No results found.</Typography></TableCell></TableRow>}
              {rows.map(r => (
                <TableRow hover key={r.id} onClick={()=>setDrawer({open:true,row:r})} sx={{cursor:'pointer'}}>
                  <TableCell><Typography noWrap title={r.title}>{r.title}</Typography></TableCell>
                  <TableCell>{r.cuisine || '-'}</TableCell>
                  <TableCell>
                    <Stack direction="row" alignItems="center" spacing={1}>
                      <Rating name="read-only" value={r.rating||0} precision={0.1} readOnly />
                      <Typography variant="body2">{r.rating?.toFixed?.(1) || '-'}</Typography>
                    </Stack>
                  </TableCell>
                  <TableCell>{r.total_time ?? '-'}</TableCell>
                  <TableCell>{r.serves ?? '-'}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
        <Box sx={{display:'flex',alignItems:'center',justifyContent:'space-between',px:2}}>
          <TablePagination component="div" count={total} page={page} onPageChange={(e,p)=>setPage(p)} rowsPerPage={rowsPerPage} onRowsPerPageChange={e=>{setRowsPerPage(parseInt(e.target.value,10)); setPage(0);}} rowsPerPageOptions={PAGE_SIZES} labelRowsPerPage="Rows per page"/>
        </Box>
      </Paper>

      <Drawer anchor="right" open={drawer.open} onClose={()=>setDrawer({open:false,row:null})}>
        <Box sx={{width:420,p:2}}>
          <Typography variant="h6" sx={{fontWeight:700}}>{drawer.row?.title} {drawer.row?.cuisine?`• ${drawer.row?.cuisine}`:''}</Typography>
          <Divider sx={{my:1.5}} />
          <KV label="Description" value={drawer.row?.description} />
          <KV label="Total Time" value={drawer.row?.total_time} />
          <details style={{marginLeft:8}}><summary style={{cursor:'pointer'}}><b>Expand Times</b></summary><KV label="Prep Time" value={drawer.row?.prep_time} /><KV label="Cook Time" value={drawer.row?.cook_time} /></details>
          <Divider sx={{my:1.5}} /><Typography variant="subtitle1" sx={{fontWeight:700}}>Nutrition</Typography>
          <Table size="small"><TableBody>{['calories','carbohydrateContent','cholesterolContent','fiberContent','proteinContent','saturatedFatContent','sodiumContent','sugarContent','fatContent'].map(k=>(<TableRow key={k}><TableCell sx={{fontWeight:600,width:'50%'}}>{k}</TableCell><TableCell>{drawer.row?.nutrients?.[k] ?? '-'}</TableCell></TableRow>))}</TableBody></Table>
        </Box>
      </Drawer>
    </Container>
  )
}
