
package com.securin.recipes.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.securin.recipes.model.Recipe;
import com.securin.recipes.repository.RecipeRepository;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;
import java.util.List;
import java.util.Objects;

@Service
@RequiredArgsConstructor
public class RecipeLoader {
    private final RecipeRepository repo;
    private final ObjectMapper mapper = new ObjectMapper();

    private static Integer parseInt(Object v) {
        try {
            if (v == null) return null;
            if (v instanceof Number n) return n.intValue();
            String s = v.toString().trim();
            if (s.equalsIgnoreCase("NaN") || s.isEmpty()) return null;
            return Integer.valueOf(s);
        } catch (Exception e) { return null; }
    }

    private static Double parseDouble(Object v) {
        try {
            if (v == null) return null;
            if (v instanceof Number n) return n.doubleValue();
            String s = v.toString().trim();
            if (s.equalsIgnoreCase("NaN") || s.isEmpty()) return null;
            return Double.valueOf(s);
        } catch (Exception e) { return null; }
    }

    private static Integer extractCalories(Map<String, Object> nutrients) {
        if (nutrients == null) return null;
        Object cal = nutrients.get("calories");
        if (cal == null) return null;
        String digits = cal.toString().replaceAll("[^0-9]", "");
        if (digits.isEmpty()) return null;
        try { return Integer.valueOf(digits); } catch (Exception e) { return null; }
    }

    public static Recipe toEntity(Map<String, Object> it) {
        try {
            String title = Objects.toString(it.getOrDefault("title", ""), "").trim();
            if (title.isEmpty()) return null;
            String cuisine = Objects.toString(it.get("cuisine"), null);
            Double rating = parseDouble(it.get("rating"));
            Integer prep = parseInt(it.get("prep_time"));
            Integer cook = parseInt(it.get("cook_time"));
            Integer total = parseInt(it.get("total_time"));
            String desc = Objects.toString(it.get("description"), null);
            @SuppressWarnings("unchecked")
            Map<String, Object> nutrients = (Map<String, Object>) it.get("nutrients");
            String serves = Objects.toString(it.get("serves"), null);
            Integer calories = extractCalories(nutrients);

            return Recipe.builder()
                    .title(title).cuisine(cuisine)
                    .rating(rating).prep_time(prep).cook_time(cook).total_time(total)
                    .description(desc).nutrients(nutrients).serves(serves).calories(calories)
                    .build();
        } catch (Exception e) {
            return null;
        }
    }

    @PostConstruct
    public void loadFromClasspath() {
        try {
            String path = System.getenv().getOrDefault("RECIPES_JSON", "recipes.json");
            if (!Files.exists(Paths.get(path))) {
                var res = getClass().getClassLoader().getResource("recipes.json");
                if (res != null) path = res.getFile();
            }
            List<Map<String, Object>> items = mapper.readValue(new File(path), new TypeReference<>() {});
            for (Map<String, Object> it : items) {
                Recipe r = toEntity(it);
                if (r != null) repo.save(r);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
