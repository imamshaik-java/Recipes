
package com.securin.recipes.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.securin.recipes.model.Recipe;
import com.securin.recipes.service.RecipeLoader;
import com.securin.recipes.repository.RecipeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/upload")
@RequiredArgsConstructor
public class UploadController {

    private final RecipeRepository repo;
    private final ObjectMapper mapper = new ObjectMapper();

    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<String> upload(@RequestPart("file") MultipartFile file) {
        try {
            List<Map<String, Object>> items = mapper.readValue(file.getInputStream(), new TypeReference<>() {});
            int count = 0;
            for (Map<String, Object> it : items) {
                Recipe r = RecipeLoader.toEntity(it);
                if (r != null) { repo.save(r); count++; }
            }
            return ResponseEntity.ok("Uploaded " + count + " recipes");
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().body("Error: " + e.getMessage());
        }
    }
}
