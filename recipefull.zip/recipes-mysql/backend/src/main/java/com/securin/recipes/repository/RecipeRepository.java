
package com.securin.recipes.repository;

import com.securin.recipes.model.Recipe;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface RecipeRepository extends JpaRepository<Recipe, Long> {

    Page<Recipe> findAllByOrderByRatingDesc(Pageable pageable);

    @Query(
        "SELECT r FROM Recipe r " +
        "WHERE (:title IS NULL OR LOWER(r.title) LIKE LOWER(CONCAT('%', :title, '%'))) " +
        "  AND (:cuisine IS NULL OR LOWER(r.cuisine) = LOWER(:cuisine)) " +
        "  AND (:ratingOp IS NULL OR (r.rating IS NOT NULL AND " +
        "       ( (:ratingOp = '=') AND r.rating = :ratingVal OR " +
        "         (:ratingOp = '>=') AND r.rating >= :ratingVal OR " +
        "         (:ratingOp = '>') AND r.rating > :ratingVal OR " +
        "         (:ratingOp = '<=') AND r.rating <= :ratingVal OR " +
        "         (:ratingOp = '<') AND r.rating < :ratingVal ))) " +
        "  AND (:totalOp IS NULL OR (r.total_time IS NOT NULL AND " +
        "       ( (:totalOp = '=') AND r.total_time = :totalVal OR " +
        "         (:totalOp = '>=') AND r.total_time >= :totalVal OR " +
        "         (:totalOp = '>') AND r.total_time > :totalVal OR " +
        "         (:totalOp = '<=') AND r.total_time <= :totalVal OR " +
        "         (:totalOp = '<') AND r.total_time < :totalVal ))) " +
        "  AND (:prepOp IS NULL OR (r.prep_time IS NOT NULL AND " +
        "       ( (:prepOp = '=') AND r.prep_time = :prepVal OR " +
        "         (:prepOp = '>=') AND r.prep_time >= :prepVal OR " +
        "         (:prepOp = '>') AND r.prep_time > :prepVal OR " +
        "         (:prepOp = '<=') AND r.prep_time <= :prepVal OR " +
        "         (:prepOp = '<') AND r.prep_time < :prepVal ))) " +
        "  AND (:cookOp IS NULL OR (r.cook_time IS NOT NULL AND " +
        "       ( (:cookOp = '=') AND r.cook_time = :cookVal OR " +
        "         (:cookOp = '>=') AND r.cook_time >= :cookVal OR " +
        "         (:cookOp = '>') AND r.cook_time > :cookVal OR " +
        "         (:cookOp = '<=') AND r.cook_time <= :cookVal OR " +
        "         (:cookOp = '<') AND r.cook_time < :cookVal ))) " +
        "  AND (:calOp IS NULL OR (r.calories IS NOT NULL AND " +
        "       ( (:calOp = '=') AND r.calories = :calVal OR " +
        "         (:calOp = '>=') AND r.calories >= :calVal OR " +
        "         (:calOp = '>') AND r.calories > :calVal OR " +
        "         (:calOp = '<=') AND r.calories <= :calVal OR " +
        "         (:calOp = '<') AND r.calories < :calVal ))) " +
        "ORDER BY r.rating DESC NULLS LAST"
    )
    Page<Recipe> search(
            @Param("title") String title,
            @Param("cuisine") String cuisine,
            @Param("ratingOp") String ratingOp, @Param("ratingVal") Double ratingVal,
            @Param("totalOp") String totalOp, @Param("totalVal") Integer totalVal,
            @Param("prepOp") String prepOp, @Param("prepVal") Integer prepVal,
            @Param("cookOp") String cookOp, @Param("cookVal") Integer cookVal,
            @Param("calOp") String calOp, @Param("calVal") Integer calVal,
            Pageable pageable
    );
}
