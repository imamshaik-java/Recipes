
package com.securin.recipes.controller;

import com.securin.recipes.model.Recipe;
import com.securin.recipes.repository.RecipeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@RestController
@RequestMapping("/api/recipes")
@CrossOrigin(origins = "*")
@RequiredArgsConstructor
public class RecipeController {

    private final RecipeRepository repo;

    record PageResponse<T>(int page, int limit, long total, List<T> data) {}

    @GetMapping
    public ResponseEntity<PageResponse<Recipe>> getAll(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int limit
    ) {
        if (page < 1) page = 1;
        if (limit < 1) limit = 10;
        Pageable pageable = PageRequest.of(page - 1, limit);
        Page<Recipe> p = repo.findAllByOrderByRatingDesc(pageable);
        return ResponseEntity.ok(new PageResponse<>(page, limit, p.getTotalElements(), p.getContent()));
    }

    private static final Pattern OP_NUM = Pattern.compile("^(<=|>=|=|<|>)([0-9]+(?:\.[0-9]+)?)$");

    private static String[] parseOpVal(String s) {
        if (s == null || s.isBlank()) return new String[]{null, null};
        Matcher m = OP_NUM.matcher(s.trim());
        if (m.matches()) return new String[]{m.group(1), m.group(2)};
        return new String[]{null, null};
    }

    @GetMapping("/search")
    public ResponseEntity<PageResponse<Recipe>> search(
            @RequestParam(required = false) String title,
            @RequestParam(required = false) String cuisine,
            @RequestParam(required = false) String rating,
            @RequestParam(required = false, name = "total_time") String totalTime,
            @RequestParam(required = false, name = "prep_time") String prepTime,
            @RequestParam(required = false, name = "cook_time") String cookTime,
            @RequestParam(required = false) String calories,
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int limit
    ) {
        String[] r = parseOpVal(rating);
        String[] t = parseOpVal(totalTime);
        String[] p = parseOpVal(prepTime);
        String[] c = parseOpVal(cookTime);
        String[] cal = parseOpVal(calories);

        Pageable pageable = PageRequest.of(Math.max(0, page - 1), limit, Sort.by(Sort.Order.desc("rating")));

        Page<Recipe> result = repo.search(
                (title == null || title.isBlank()) ? null : title,
                (cuisine == null || cuisine.isBlank()) ? null : cuisine,
                r[0], r[1] == null ? null : Double.valueOf(r[1]),
                t[0], t[1] == null ? null : Integer.valueOf(t[1]),
                p[0], p[1] == null ? null : Integer.valueOf(p[1]),
                c[0], c[1] == null ? null : Integer.valueOf(c[1]),
                cal[0], cal[1] == null ? null : Integer.valueOf(cal[1]),
                pageable
        );

        return ResponseEntity.ok(new PageResponse<>(page, limit, result.getTotalElements(), result.getContent()));
    }
}
