recipes -Mysql
for runining backend
-------------------
1)import the backend code in eclipse ->
2) in application.yml file change my sql prooerties 
           user-name 
           password 
3) run the code conatains main method RecipeApplication.java file as Run as java
4) in console it will show the the programm is running at port number 8080
5) then start fronted 


for runniung fronted 
----------------------
1) import the frontend code in vscode
2)open new terminal
3)type cd frontend
4) npm install
5) npm install axios
6) npm run dev
7) it will run successfully and give a link follow the link


workimg principle of website
----------------------------
1)  it will show the home at right corner of page there will be a button upload JSON
=> click the button and upload a json file 
=> on submisson you will get response from backed did the file parse into date and stored are not
=> if succesfully stored and parsed then you can perfrom any any action using another button placed in desktop
 

